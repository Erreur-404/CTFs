import random
import json

bingo_seed = 1
random.seed(bingo_seed)

L_B = list(range(1, 16))
L_I = list(range(16, 31))
L_N = list(range(31, 46))
L_G = list(range(46, 61))
L_O = list(range(61, 76))

all_cards = []

for i in range(600000):
    number_card = (
        random.sample(L_B, k=5),
        random.sample(L_I, k=5),
        random.sample(L_N, k=5),
        random.sample(L_G, k=5),
        random.sample(L_O, k=5),
    )

    all_cards.append({
        'card_id': i,
        'card_numbers': number_card
    })

with open('cards.json', 'w') as f:
    json.dump(all_cards, f)
