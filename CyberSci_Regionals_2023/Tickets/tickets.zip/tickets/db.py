import click
import sqlite3
from flask import current_app, g

def initApp(app):
    app.teardown_appcontext(close)
    app.cli.add_command(initDB_cli)

def initDB():
    db = connection()
    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf-8'))

def connection():
    if 'db' not in g or not isinstance(g.db, sqlite3.Connection):
        g.db = sqlite3.connect(current_app.config.get('DBPATH'),
            detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row

    return g.db

def cursor():
    return connection().cursor()

def close(e=None):
    dbconn = g.pop('db', None)
    if dbconn is not None:
        dbconn.close()

@click.command('init-db')
def initDB_cli():
    initDB()
    click.echo("Database initialized.")
