from flask import Flask, request, url_for, session, g, render_template, \
                  Blueprint, current_app, abort, jsonify, make_response
from tickets.db import cursor as dbCursor
from .ref import NSDict
import sqlite3
import datetime

web = Blueprint('web', __name__)

@web.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@web.route("/packages", methods=["GET"])
def listPackages():
    sql = """SELECT * FROM packages WHERE enabled = 1"""
    cur = dbCursor()

    rs = cur.execute(sql).fetchall()
    packages = NSDict.fromRecordSet(rs)
    return render_template("packageList.html", packages=packages)

def __getPackage(id, enabled=False):
    sql = "SELECT * FROM packages WHERE id = :id"
    if enabled:
        sql += " AND enabled = 1"

    cur = dbCursor()
    rs = cur.execute(sql, {'id': id}).fetchone()
    return None if rs is None else NSDict.fromRec(rs)

@web.route('/packages/<id>', methods=["GET"])
def getPackage(id):
    pkg = __getPackage(id)
    if pkg is None:
        abort(404)
    else:
        return render_template("packageDetail.html", package=pkg)

@web.route('/buy', methods=["POST"])
def buyPackage():
    package = request.form["packageId"]
    pkg = __getPackage(package, True)

    message = None
    if pkg is None:
        message = "An invalid package was specified."
    
    return render_template(
        "buyPackage.html",
        package=pkg,
        message=message,
        billing=None
        )

@web.route('/purchase', methods=["POST"])
def purchase():
    package = request.form["packageId"]
    pkg = __getPackage(package, True)
    billing = NSDict(
        email=request.form['email'],
        name=request.form['name'],
        card=request.form['ccard'],
        addr=request.form['address']
    )

    if billing.card == '4444 1111 2222 3333': 
        return render_template(
            "purchaseComplete.html",
            package=pkg,
            billing=billing,
            paymentdate=datetime.datetime.now()
            )
    else:
        message = "Invalid credit card."
        return render_template(
            "buyPackage.html",
            package=pkg,
            message=message,
            billing=billing,
            showform=True
            )

@web.route('/events', methods=["GET"])
def listEvents():
    sql = """SELECT * FROM events WHERE enabled = 1 ORDER BY startTime"""
    cur = dbCursor()

    rs = cur.execute(sql).fetchall()
    evts = NSDict.fromRecordSet(rs)
    return render_template("eventList.html", events=evts)


@web.route('/events/<id>', methods=["GET"])
def getEvent(id):
    sql = """SELECT * FROM events WHERE id = :id"""
    cur = dbCursor()

    rs = cur.execute(sql, {'id': id}).fetchone()
    if rs is None:
        abort(404)
    else:
        evts = NSDict.fromRec(rs)
        return render_template("eventDetail.html", events=evts)


@web.route("/search", methods=["GET"])
def getSearch():
    return render_template("search.html")

@web.route("/search", methods=["POST"])
def getResults():
    # On the query, replace ' with %27 and then search. Otherwise, ignore.
    query = request.form['query'] #.replace("'", "''")

    searchSQL = f"""
        SELECT
            rowid,
            name,
            description,
            'E' as type,
            rank as rank
        FROM    events_fts
        WHERE   name MATCH '{query}'
        OR      description MATCH '{query}'
        UNION SELECT
            rowid,
            name,
            description,
            'P' as type,
            rank as rank
        FROM    packages_fts
        WHERE   name MATCH '{query}'
        OR      description MATCH '{query}'
        ORDER BY rank
        """
    current_app.logger.debug(searchSQL)

    try:
        cur = dbCursor()
        rs = cur.execute(searchSQL).fetchall()
        return render_template("search.html", results=rs, searchQuery=query)
    except sqlite3.OperationalError as oe:
        return jsonify({
                'status': 500, 
                'error': str(oe)
            })


@web.route('/robots.txt', methods=["GET"])
def getRobots():
    if 'iOS' in request.headers.get('User-Agent') or \
       'Android' in request.headers.get('User-Agent'):
       resp = make_response(render_template("robots-mobile.txt"))
    else:
        resp = make_response(render_template("robots.txt"))
    
    resp.headers['Content-Type'] = "text/plain"
    return resp

@web.route("/events/bypass/fee_discount", methods=["GET"])
def getEventsFeeDiscount():
    return render_template("events_fee_discount.html")

@web.route("/.well-known/security.txt", methods=["GET"])
def getSecurityTxt():
    resp = make_response(render_template("security.txt"))
    resp.headers['Content-Type'] = "text/plain"

    return resp

@web.route("/.well-known/gpg.public.key", methods=["GET"])
def getGPGPubkey():
    resp = make_response(render_template("gpg.public.key"))
    resp.headers['Content-Type'] = "text/plain"

    return resp

@web.route("/security_contact", methods=["GET"])
def securityContact():
    return render_template("security_contact.html")
