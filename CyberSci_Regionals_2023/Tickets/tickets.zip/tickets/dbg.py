# This is only used in Challenge 2: demo
class EventPackage:
    def __init__(self, name, description, price):
        self.name = name
        self.description = description
        self.price = price