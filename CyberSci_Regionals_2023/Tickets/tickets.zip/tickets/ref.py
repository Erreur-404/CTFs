class NSDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    def keyFor(self, val):
        for k, v in self.items():
            if val == v:
                return k
        
        return None

    @staticmethod
    def fromRec(rec):
        ret = NSDict()
        keys = rec.keys()
        for k in keys:
            ret[k] = rec[k]
        
        return ret

    @staticmethod
    def fromRecordSet(rs, keyName=None):
        ret = []
        for rec in rs:
            ret.append(NSDict.fromRec(rec))

        if keyName is None:
            return ret
        else: 
            return { keyName: ret }
