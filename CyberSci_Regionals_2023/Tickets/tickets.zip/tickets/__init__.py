import sys, os
import datetime
import sqlite3
from flask import Flask, request, url_for, session, g, render_template, abort, jsonify
from werkzeug.middleware.proxy_fix import ProxyFix
from enum import Enum
from functools import wraps, total_ordering
import locale

locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
from . import db

"""
User role enum
"""
@total_ordering
class Role(Enum):
    GUEST = 0
    USER = 1
    EVENTADMIN = 6
    SUPERADMIN = 9

    def __eq__(self, other):
        if self.__class__ is other.__class__:
            return self.value == other.value
        return NotImplemented

    def __lt__(self, other):
        if self.__class__ is other.__class__:
            return self.value < other.value
        return NotImplemented

"""
Require administrative role to be able to access functionality
"""
def requireAdmin(requiredRole):
    def __requireAdmin(func):
        @wraps(func)
        def __checkAdmin(*args, **kwargs):
            if 'user' in session and 'role' in session['user']:
                role = Role(int(session.user.role))
                if role >= requiredRole:
                    return func(*args, **kwargs)
                else:
                    abort(401)
            elif 'AuthToken' in request.headers:
                headerToken = request.headers['AuthToken']
                cur = db.cursor()
                cur.execute("""
                    SELECT  role
                    FROM    users JOIN userAuthTokens
                    ON      userAuthTokens.userid = users.id
                    WHERE   userAuthTokens.token = :token
                    """, {'token': headerToken})
                rec = cur.fetchone()

                if rec is None:
                    abort(401)

                role = Role(int(rec['role']))
                if role >= requiredRole:
                    return func(*args, **kwargs)
                else:
                    abort(401)
            else:
                abort(401)
        return __checkAdmin
    return __requireAdmin


"""
Create the Flask app
"""
def create_app():
    app = Flask(__name__, instance_relative_config=True)

    if not os.path.exists(app.instance_path):
        os.mkdir(app.instance_path)

    app.config.from_mapping(
        DBPATH=os.path.join(app.instance_path, "tix.db"),
        SECRET_KEY=os.urandom(12),
        WTF_CSRF_SECRET_KEY=os.urandom(12),
        SESSION_COOKIE_NAME="TIX_SESS",
        SESSION_COOKIE_SECURE=True,
        SESSION_COOKIE_SAMESITE="Strict",
        PERMANENT_SESSION_LIFETIME=datetime.timedelta(hours=2).total_seconds(),
    )

    app.wsgi_app = ProxyFix(app.wsgi_app)
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True

    @app.template_filter('dateformat')
    def dateFormat(dt):
        if isinstance(dt,datetime.datetime):
            d = dt
        else:
            d = datetime.datetime.fromisoformat(dt)

        return d.strftime("%b %d")

    @app.template_filter('timeformat')
    def timeFormat(dt):
        if isinstance(dt,datetime.datetime):
            d = dt
        else:
            d = datetime.datetime.fromisoformat(dt)

        return d.strftime("%I:%M %p")

    @app.template_filter('datetimeformat')
    def datetimeFormat(dt):
        date = dateFormat(dt)
        time = timeFormat(dt)
        return f"{date} {time}"

    @app.template_filter('currency')
    def currency(cur):
        return locale.currency(cur)

    app.jinja_env.filters['dateformat'] = dateFormat
    app.jinja_env.filters['timeformat'] = timeFormat
    app.jinja_env.filters['datetimeformat'] = datetimeFormat
    app.jinja_env.filters['currency'] = currency

    def uncaught(exType, exVal, exTrace):
        app.logger.error(f"Unhandled Execption: {exType}", exc_info=(exType, exVal, exTrace))

    sys.excepthook = uncaught

    @app.after_request
    def apply_headers(resp):
        resp.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self';"
        resp.headers['Cache-Control'] = "no-cache, no-store, must-revalidate"
        resp.headers['Pragma'] = "no-cache"
        resp.headers['Strict-Transport-Security'] = "max-age=63072000; includeSubDomains"

        return resp

    """ Utility """
    from . import db
    db.initApp(app)

    @app.route('/status', methods=["POST"])
    def getStatus():
        data = request.get_json()

        username = ""
        if 'user' in data:
            u = data['user']
            if '__' in u:
                u = ""

            username = f',"requestor": "{u}"'
        
        lastUpdate = datetime.datetime.now()
        status = "ok"
        settings = { "status_token":"zQLnVxGN3ZVHdxoZ6Rfu6Zoz" }

        tplString = f"""
        {{
            "status": "{{{{status}}}}","lastUpdate": "{{{{update}}}}"{username}
        }}"""

        try: 
            from jinja2 import Environment, BaseLoader

            rtpl = Environment(loader=BaseLoader).from_string(tplString)

            return rtpl.render(status=status, update=lastUpdate, settings=settings)
        except:
            return jsonify({"status":"unknown"}), 400

    """ Blueprints """
    from . import api, account, web
    app.register_blueprint(api.api, url_prefix='/api')
    app.register_blueprint(account.account, url_prefix='/account')
    app.register_blueprint(web.web, url_prefix='')

    app.logger.debug(app.url_map)

    return app
