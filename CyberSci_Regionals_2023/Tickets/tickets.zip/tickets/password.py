import bcrypt

WORKFACTOR=12

def hash(password):
    global WORKFACTOR

    salt=bcrypt.gensalt(rounds=WORKFACTOR)

    if type(password) == bytes:
        return bcrypt.hashpw(password, salt)
    elif type(password) == str:
        return bcrypt.hashpw(password.encode(), salt)
    else:
        raise(ValueError("Password was not supplied as string or bytes"))

def check(password, dbval):
    if type(password) == str:
        password = password.encode()
    elif type(password) != bytes:
        raise(ValueError("Password was not supplied as string or bytes"))

    if type(dbval) == str:
        dbval = dbval.encode()
    elif type(dbval) != bytes:
        raise(ValueError("DB Value was not supplied as string or bytes"))

    return bcrypt.checkpw(password, dbval)