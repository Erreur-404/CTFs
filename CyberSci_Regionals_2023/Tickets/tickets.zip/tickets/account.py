from flask import Flask, request, url_for, session, g, render_template, Blueprint
from tickets import requireAdmin, Role

account = Blueprint('account', __name__)

@account.route("/accounts", methods=["GET"])
@requireAdmin(Role.EVENTADMIN)
def viewAccountList():
    # TODO: Get list of accounts and feed to render_template

    return render_template("accounts/accountList.html")

@account.route("/account/<userid>", methods=["GET"])
@requireAdmin(Role.EVENTADMIN)
def viewAccountDetail():
    # TODO: Get account detail and feed to render_template

    return render_template("accounts/account.html")
