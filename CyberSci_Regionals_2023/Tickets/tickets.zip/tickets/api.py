import base64
from flask import Flask, request, session, g, render_template, Blueprint, \
                  abort, make_response, jsonify
from functools import wraps
from enum import Enum
import secrets
import datetime
from tickets import requireAdmin, Role
from . import db, password
from .ref import NSDict

api = Blueprint('api', __name__)

"""
Check that the AuthToken is provided via the header and matches what is in the session
OR that the AuthToken in the header matches what is in the database, if not available
in the session.
"""
def requireToken(func):
    @wraps(func)
    def checkToken(*args, **kwargs):
        if 'user' in session and 'token' in session['user']:
            if request.headers["AuthToken"] == session.user.token:
                return func(*args, **kwargs)
            else:
                abort(401)
        elif "AuthToken" not in request.headers:
            abort(400)
        else:
            headerToken = request.headers["AuthToken"]
            cur = db.cursor()
            cur.execute("""
                SELECT  id, username, token, role
                FROM    users JOIN userAuthTokens
                ON      userAuthTokens.userid = users.id
                WHERE   userAuthTokens.token = :token
                """, {'token': headerToken})
            rec = cur.fetchone()

            if rec is None:
                abort(401)
            else:
                session.user = NSDict(
                    id=rec['id'],
                    name=rec['username'],
                    token=rec['token'],
                    role=rec['role']
                )
                return func(*args, **kwargs)
    return checkToken



"""
Change the current user's password

Expected input (application/json):
{
    "current_password": "User's current password",
    "new_password": "New password"
}

Returns:
- 201 Created: Password successfully changed
- 401 Unauthorized: Current password check failed
- 403 Bad Request: Request was not JSON or Content-type: application/json
"""
@api.route("/account/password", methods=["POST"])
@requireToken
def changePassword():
    if not request.is_json:
        abort(403)

    data = request.json

    existingPW = data['current_password']

    cur = db.cursor()
    cur.execute("""
        SELECT password
        FROM users
        WHERE id = :currentid
        """, {'currentid': session.user.id})
    rec = cur.fetchone()

    if not password.checkpw(existingPW, rec['password']):
        abort(401)
    else:
        newPW = data['new_password']
        newPassword = password.hash(newPW)
        cur.execute("""
            UPDATE users
            SET password = :newpass
            WHERE id = :currentid
            """, {'newpass':newPassword, 'currentid': session.user.id})
        return '', 201


"""
Log in

Expected input (application/json):
{
    "username": "The username",
    "password": "The password"
}

Returns:
- 200 OK:
  ```
  {
      "token": "User's session token value"
  }
  ```
- 401 Unauthorized: Login failed
"""
@api.route("/account/login", methods=["POST"])
def login():
    if not request.is_json:
        abort(403)

    data = request.json

    username = data['username']
    passwd = data['password']

    cur = db.cursor()
    cur.execute("""
        SELECT *
        FROM users
        WHERE username = :username
        """, {'username': username})
    rec = cur.fetchone()

    if rec is None or \
        not password.check(passwd, rec['password']) or \
        int(rec['enabled']) == 0:
        abort(401)
    else:
        session.user = NSDict(
            id=rec['id'],
            name=rec['username'],
            token=secrets.token_urlsafe(16),
            role=rec['role']
        )

        cur.execute("""
            DELETE FROM userAuthTokens
            WHERE userid = :userid
            """, {'userid': session.user.id})
        db.connection().commit()

        cur.execute("""
            INSERT INTO userAuthTokens (userid, token)
            VALUES (:userid, :token)
            """, {'userid':session.user.id, 'token':session.user.token})
        db.connection().commit()

        return jsonify({'token': session.user.token})


""" Private account retrieval method """
def __getUserProfile(userid):
    cur = db.cursor()
    rec = cur.execute("""
        SELECT username, enabled
        FROM users
        WHERE userid = :userid
        """, {"userid": userid})
    rec = cur.fetchone()
    return NSDict(username=rec['username'], enabled=rec['enabled'])


"""
Get the account profile for current user

Returns (application/json):
{
    "username": "The user's username",
    "enabled": 1
}
"""
@api.route("/account/profile", methods=["GET"])
@requireToken
def getCurrentProfile():
    return jsonify(__getUserProfile(session.user.id))


"""
Get the account profile for another user (ADMIN Functionality)
"""
@api.route("/account/<userid>", methods=["GET"])
@requireToken
@requireAdmin(Role.SUPERADMIN)
def getProfile(userid=None):
    return jsonify(__getUserProfile(userid))


""" Private account profile update method - disabled for now"""
def __updateProfile():
    return None


"""
Modify the current user's profile
"""
@api.route("/account/profile", methods=["POST"])
@requireToken
def changeCurrentProfile():
    return jsonify(__updateProfile())


"""
Modify the specified user's profile (ADMIN Functionality)
"""
@api.route("/account/<userid>", methods=["POST"])
@requireToken
@requireAdmin(Role.SUPERADMIN)
def changeProfile(userid):
    return jsonify(__updateProfile())


"""
Delete the specifi3ed user (ADMIN Functionality)
"""
@api.route("/account/<userid>", methods=["DELETE"])
@requireToken
@requireAdmin(Role.SUPERADMIN)
def deleteUser(userid):
    cur = db.cursor()
    cur.execute("""
        UPDATE users SET enabled = 0 WHERE userid = :userid
        """, {"userid": userid})

    db.connection().commit()

    return jsonify({})


"""
Get purchase history for current account.

Returns:
{
    "purchases": [
        {
            "date": "2020-01-01T23:59:59.000Z",
            "packageid": 1234,
            "name": "Sample Package",
            "cost": "$99.95"
        },
        {
            "date": "2020-01-02T11:22:33.999Z",
            "package": { "id": 2468, "name": "New Sample Package" },
            "cost": "$149.95"
        },
    ]
}
"""
@api.route("/account/purchases", methods=["GET"])
@requireToken
def getPurchases():
    cur = db.cursor()
    cur.execute("""
        SELECT  ph.date, ph.packageid, p.name
        FROM    purchaseHistory ph, packages p
        WHERE   p.id = ph.packageid
        AND     ph.userid = :userid
        ORDER BY ph.date DESC, p.name
        """, { "userid": session.user.id })
    recs = cur.fetchall()

    ret = NSDict(purchases=[])
    for rec in recs:
        ret.purchases.append(NSDict.fromRec(rec))

    return jsonify(ret)


"""
Register a new user account.
"""
@api.route("/accounts", methods=["PUT"])
def registration():
    if not request.is_json:
        abort(400)

    data = request.json

    username = data['username']
    password_plain = data['password']

    cur = db.cursor()
    cur.execute("""
        SELECT username
        FROM users
        WHERE username = :username
        """, {'username': username})
    rec = cur.fetchone()
    if rec is not None:
        abort(400)

    password_hashed = password.hash(password_plain)
    cur.execute("""
        INSERT INTO users (username, password, enabled)
        VALUES (:username, :password, 1)
        """, {'username': username, 'password': password_hashed})
    db.connection().commit()

    return jsonify({})

"""
Search packages.
"""
@api.route("/search", methods=["POST"])
@requireToken
def search():
    if not request.is_json:
        abort(400)

    data = request.json

    if not isinstance(data, dict):
        abort(400)

    if 'name' not in data:
        abort(400)

    name = data['name']

    cur = db.cursor()
    cur.execute("""
        SELECT *
        FROM packages
        WHERE name = :name
        """, {'name': name})
    rec = cur.fetchone()

    if rec is None:
        abort(404)

    return jsonify(NSDict.fromRec(rec))


def _getPackage(packageid):
    cur = db.cursor()
    cur.execute("""
        SELECT *
        FROM packages
        WHERE id = :packageid AND enabled = 1
        """, {'packageid': packageid})
    rec = cur.fetchone()
    return rec


"""
Purchase a package.
"""
@api.route("/purchase/<packageid>", methods=["PUT"])
@requireToken
def purchase(packageid):
    try:
        packageid = int(packageid)  # We need the packageid to be an int for our queries
    except ValueError:
        abort(400)

    rec = _getPackage(packageid)
    if rec is None:
        abort(404)

    values = {
        'packageid': packageid,
        'userid': session.user.id,
        'date': datetime.datetime.now(),
    }
    cur = db.cursor()
    cur.execute("""
        INSERT INTO purchaseHistory (packageid, userid, date)
        VALUES (:packageid, :userid, :date)
        """, values)
    db.connection().commit()

    return jsonify({})


"""
Get a list of packages.

Returns:
{
    "packages": [
        {
            "date": "2020-01-01T23:59:59.000Z",
            "packageid": 1234,
            "name": "Sample Package",
            "cost": "$99.95"
        },
        {
            "date": "2020-01-02T11:22:33.999Z",
            "package": { "id": 2468, "name": "New Sample Package" },
            "cost": "$149.95"
        }
    ]
}
"""
@api.route("/packages", methods=["GET"])
def packages():
    cur = db.cursor()
    cur.execute("""
        SELECT  *
        FROM    packages
        WHERE enabled = 1
        ORDER BY price DESC, name
        """)
    recs = cur.fetchall()

    ret = NSDict.fromRecordSet(recs, keyName="packages")
    return jsonify(ret)


import pickle
import tickets.dbg
import io
# Somebody told me pickle was unsafe, so I should filter input, but if you are an admin you must be good
class RestrictedUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if not module in ["posix", "subprocess", "base64"]:
            return super().find_class(module, name)
        raise pickle.UnpicklingError(f"Attack Detected")

filters = [b"import os", b".system", b'__import__("os")', b"__import__('os')", b"subprocess", b"base64"]
def deserialize_package(req_data):
    try:
        if any([x in req_data for x in filters]):
            return f'Error: {str(req_data)} triggered filters', 1
        obj = RestrictedUnpickler(io.BytesIO(req_data)).load()
        return obj, 0
    except Exception as e:
        return str(e), 2

"""
Create a new package (EVENTADMIN or higher functionality)
"""
@api.route("/packages", methods=["PUT"])
@requireToken
@requireAdmin(Role.EVENTADMIN)
def addPackage():
    # Packages can be submitted as serialized objects to automate package creation
    if not request.is_json:
        d = request.data
        s, rv = deserialize_package(d)
        if rv == 0:
            if hasattr(s, "name") and hasattr(s, "description") and hasattr(s, "price"):
                name = s.name
                description = s.description
                price = s.price
            else:
                s = f'Error: {s}'
                abort(400, s)
        else:
            abort(400, s)
    else:
        data = request.json
        if not isinstance(data, dict):
            abort(400)

        try:
            name = data['name']
            description = data['description']
            price = data['price']
        except KeyError:
            abort(400)

    cur = db.cursor()
    cur.execute("""
        INSERT INTO packages (name, description, price)
        VALUES (:name, :description, :price)
        """, {'name': name, 'description': description, 'price': price})
    db.connection().commit()

    cur.execute("""
        SELECT *
        FROM packages
        WHERE name = :name
        """, {'name': name})
    rec = cur.fetchone()

    return jsonify(NSDict.fromRec(rec))


"""
Get details for an individual package. (No auth required)
"""
@api.route("/package/<packageid>", methods=["GET"])
def getPackage(packageid):
    try:
        packageid = int(packageid)  # We need the packageid to be an int for our queries
    except ValueError:
        abort(400)

    rec = _getPackage(packageid)
    if rec is None:
        abort(404)
    return jsonify(NSDict.fromRec(rec))


"""
Modify a package.
"""
@api.route("/package/<packageid>", methods=["POST"])
@requireToken
@requireAdmin(Role.EVENTADMIN)
def modifyPackage(packageid):
    try:
        packageid = int(packageid)  # We need the packageid to be an int for our queries
    except ValueError:
        abort(400)

    if not request.is_json:
        abort(400)

    data = request.json
    if not isinstance(data, dict):
        abort(400)

    try:
        description = data['description']
        price = data['price']
    except KeyError:
        abort(400)

    cur = db.cursor()
    cur.execute("""
        UPDATE packages
        SET description = :description, price = :price
        WHERE id = :packageid AND enabled = 1
        """, {'description': description, 'price': price, 'packageid': packageid})
    db.connection().commit()

    return jsonify({})


"""
Delete a package.
"""
@api.route("/package/<packageid>", methods=["DELETE"])
@requireToken
@requireAdmin(Role.EVENTADMIN)
def deletePackage(packageid):
    try:
        packageid = int(packageid)  # We need the packageid to be an int for our queries
    except ValueError:
        abort(400)

    rec = _getPackage(packageid)
    if rec is None:
        abort(404)

    cur = db.cursor()
    cur.execute("""
        DELETE FROM packages
        WHERE id = :packageid
        """, {'packageid': packageid})
    db.connection().commit()

    return jsonify({})


"""
Create the user's ticket
"""
@api.route("/ticket", methods=["PUT"])
@requireToken
def createTicket():
    # TODO: Sign the submitted ticket using key from env

    """ Process:

    - Take provided ticket JSON in.
    - If ticket.id < 100, this is part of our testing data, so just let it through regardless. Otherwise,
      if ticket.id already exists in the db, throw an error - this ticket has already been signed.
    - If ticket.id doesn't exist, sign the data provided and return the signed value to the user.
    - Once ticket is signed, it's super valid, so update the ticket in the tickets db table. If id < 100
      overwrite the data there instead of validating it, except for our secret field.
    - Return all signed ticket data to the user as QR code.
    """

    signedTicket = base64.b64encode(0x70d070d070d0) #TODO
    signedTicketQR = base64.b64encode(signedTicket)

    return jsonify({"QR": signedTicketQR})
