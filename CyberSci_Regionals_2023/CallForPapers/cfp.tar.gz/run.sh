#!/usr/bin/env bash
service nginx start
service php7.4-fpm start
sleep infinity